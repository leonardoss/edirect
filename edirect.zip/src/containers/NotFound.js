import React from 'react';

const NotFound = () => (
  <div className="notfound">
    <h1>NotFound 404</h1>
  </div>
);

export default NotFound;
